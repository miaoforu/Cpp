#ifndef ENEMYVIEW_H
#define ENEMYVIEW_H

#include "world.h"
#include "ui_mainwindow.h"
#include <QGraphicsView>
#include <QGraphicsPixmapItem>
#include "XEnemy.h"

using namespace  std;

class GraphicalEnemy: public QObject
{
    Q_OBJECT
public:
    GraphicalEnemy(shared_ptr<Enemy> &enemy, QGraphicsScene* scene, int size);
    ~GraphicalEnemy();


public slots:
    void showDeadEnemy();
    void updateXEnemy(int x, int y);

private:
    QGraphicsPixmapItem* item;
    int size;
    QString imageDead;
};
#endif // ENEMYVIEW_H
