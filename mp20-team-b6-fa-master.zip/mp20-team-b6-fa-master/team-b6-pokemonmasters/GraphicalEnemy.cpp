#include "GraphicalEnemy.h"
#include <QDebug>

GraphicalEnemy::GraphicalEnemy(std::shared_ptr<Enemy>& enemy, QGraphicsScene* scene, int scaleSize)
{
   int x = enemy->getXPos();
   int y = enemy->getYPos();
   size = scaleSize;

   if (dynamic_cast<PEnemy*>(enemy.get()))
   {
       item = new QGraphicsPixmapItem(QPixmap(":/icons/PEnemy").scaled(size,size));
       imageDead = ":/icons/PEnemyDead";
   }
   else if(dynamic_cast<XEnemy*>(enemy.get()))
   {
       item = new QGraphicsPixmapItem(QPixmap(":/icons/XEnemy").scaled(size,size));
       imageDead = ":/icons/XEnemyDead";

       XEnemy* xe = dynamic_cast<XEnemy*>(enemy.get());
       connect(xe, SIGNAL(positionUpdated(int,int)), this, SLOT(updateXEnemy(int,int)));
   }
   else
   {
       item = new QGraphicsPixmapItem(QPixmap(":/icons/Enemy").scaled(size,size));
       imageDead = ":/icons/EnemyDead";
   }

   item->setPos(QPoint(x*size,y*size));
   scene->addItem(item);
}

GraphicalEnemy::~GraphicalEnemy()
{

}

void GraphicalEnemy::showDeadEnemy()
{
    item->setPixmap(QPixmap(imageDead).scaled(size,size));
}

void GraphicalEnemy::updateXEnemy(int x, int y)
{
    item->setPos(QPoint(x*size,y*size));
}



