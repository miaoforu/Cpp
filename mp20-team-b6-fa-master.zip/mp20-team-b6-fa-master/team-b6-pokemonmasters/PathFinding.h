#ifndef MP20_TEAM_B6_FA_PATHFINDING_H
#define MP20_TEAM_B6_FA_PATHFINDING_H

#include "world.h"
#include "world_global.h"
#include "Node.h"
#include <queue>
#include <iostream>
#include <math.h>
using namespace std;

class PathFinding
{
public:
    PathFinding(WorldModel& world);
    vector<shared_ptr<Tile>> pathFinding(const Tile& start, const Tile& end) const;
    vector<shared_ptr<Tile>> findNeighbors(const Node & node) const;
    void setGWeight(float gWeight);
    void setHWeight(float hWeight);

private:
    vector<shared_ptr<Tile>> grid;
    shared_ptr<Node> findNode(const shared_ptr<Node>& node, const vector<shared_ptr<Node>>& openList) const;
    unsigned int getPos(const shared_ptr<Node>& node) const;
    int numCols;
    int numRows;
    float gWeight;
    float hWeight;
    typedef pair<float, shared_ptr<Node>> nodePair;

};

bool compareTwoNodes(shared_ptr<Node> n1, shared_ptr<Node> n2);
vector<shared_ptr<Tile>> reconstructPath(vector<shared_ptr<Node>> closedList,shared_ptr<Node> startNode);

#endif //MP20_TEAM_B6_FA_PATHFINDING_H
