#include "WorldModel.h"
#include <QDebug>

WorldModel::WorldModel(QString filename, unsigned int nrOfEnemies, unsigned int nrOfHealthpacks)
{
    this->numEnemies = nrOfEnemies;
    unsigned int numXE = 3*floor(nrOfEnemies/10);
    this->curWorld = make_shared<World>();
    this->curWorld->createWorld(filename, nrOfEnemies-numXE, nrOfHealthpacks);
    this->numRows = this->curWorld->getRows();
    this->numCols = this->curWorld->getCols();

    vector<unique_ptr<Tile>> tempTile = curWorld->getTiles();
    for(unsigned int i = 0; i<tempTile.size(); i++)
    {
        allTiles.emplace_back(move(tempTile[i]));
    }

    vector<unique_ptr<Enemy>> tempEnemy = curWorld->getEnemies();
    for(unsigned int i = 0; i<tempEnemy.size(); i++)
    {
       allEnemies.emplace_back(move(tempEnemy[i]));
    }

    vector<unique_ptr<Tile>> tempHealth = curWorld->getHealthPacks();
    for(unsigned int i = 0; i<tempHealth.size(); i++)
    {
        allHealthPacks.emplace_back(move(tempHealth[i]));
    }

    myProtagonist = curWorld->getProtagonist();

    initialMapTiles();
    createXEnemies(numXE);
}

void WorldModel::initialMapTiles()
{
    // map tiles
    for(auto tile: allTiles)
    {
        mapTiles.insert(pair(tile, 0));
    }

    for(auto enemy: allEnemies)
    {
        int x = enemy->getXPos();
        int y = enemy->getYPos();
        shared_ptr<Tile> t = allTiles[y*numCols+x];
        mapTiles[t] = 1;
        if (dynamic_cast<PEnemy*>(enemy.get()))
        {
            PEnemy* pe = dynamic_cast<PEnemy*>(enemy.get());
            connect(pe, SIGNAL(poisonLevelUpdated(int)), this, SLOT(poisonTile()));
        }
    }

    for(auto hp: allHealthPacks)
    {
        int x = hp->getXPos();
        int y = hp->getYPos();
        shared_ptr<Tile> t = allTiles[y*numCols+x];
        mapTiles[t] = 4;
    }
}

void WorldModel::createXEnemies(int num)
{
    int count = 0;
    while(count != num)
    {
        int x = rand()%numCols;
        int y = rand()%numRows;
        shared_ptr<Tile> t = allTiles[y*numCols+x];
        if(mapTiles[t]==0 && (x!=0 && y!=0))
        {
            count++;
            mapTiles[t]=1;
            unique_ptr <XEnemy> thisEnemy = make_unique<XEnemy>(x, y, rand()%100);
            this->allEnemies.emplace_back(move(thisEnemy));
        }
    }
}



shared_ptr<World> WorldModel::getWorld() {
    return curWorld;
}

shared_ptr<Protagonist> WorldModel::getProtagonist() {
    return myProtagonist;
}

vector<shared_ptr<Tile>> WorldModel::getAllTiles() {
    return allTiles;
}

vector<shared_ptr<Enemy>> WorldModel::getAllEnemies() {
    return allEnemies;
}

vector<shared_ptr<Tile>> WorldModel::getAllHealthPacks() {
    return allHealthPacks;
}

int WorldModel::getNumEnemies() const{
    return numEnemies;
}

int WorldModel::getRows() const{
    return numRows;
}

int WorldModel::getCols() const{
    return numCols;
}

QTimer *WorldModel::getTimerPoison()
{
    return timerPoison;
}

int WorldModel::getMapValue(shared_ptr<Tile> tile)
{
    return mapTiles[tile];
}

void WorldModel::moveTo(int direction)
{
    int x = myProtagonist->getXPos();
    int y = myProtagonist->getYPos();

    switch (direction) {
    // move up
    case 1:
    {
        if(detectEnemy(x,y-1)) break;
        collectHealthpack(x,y-1);
        myProtagonist->setPos(x,y-1);
        break;
    }
        // down
    case 2:
    {
        if(detectEnemy(x,y+1)) break;
        collectHealthpack(x,y+1);
        myProtagonist->setPos(x,y+1);
        break;
    }
        // left
    case 3:
    {
        if(detectEnemy(x-1,y)) break;
        collectHealthpack(x-1,y);
        myProtagonist->setPos(x-1,y);
        break;
    }
        // right
    case 4:
    {
        if(detectEnemy(x+1,y)) break;
        collectHealthpack(x+1,y);
        myProtagonist->setPos(x+1,y);
        break;
    }
    }
//    qDebug()<<"protagonist at: "<< myProtagonist->getXPos()<< myProtagonist->getYPos();
}

void WorldModel::collectHealthpack(int x, int y)
{
    vector<shared_ptr<Tile>>::iterator it;
    for (it = allHealthPacks.begin(); it<allHealthPacks.end(); it++)
    {
        if((x == (*it)->getXPos())&&(y == (*it)->getYPos()))
        {
            myProtagonist->setHealth(myProtagonist->getHealth() + 10);
            if(myProtagonist->getHealth()>100) myProtagonist->setHealth(100);
//            qDebug() << (*it)->getXPos()<< (*it)->getYPos();
//            qDebug()<<"Healthpack collected, newHealth = "<<myProtagonist->getHealth() ;
            used_healthpacks.push_back(*it);
            emit GRemoveItem((*it)->getXPos(),(*it)->getYPos());
            allHealthPacks.erase(it);



            shared_ptr<Tile> t = allTiles[y*numCols+x];
            mapTiles[t] = 0;
        }
    }
}

bool WorldModel::detectEnemy(int x, int y)
{
//    Tile* nextTile = allTiles.at(y*numCols+x).get();
    shared_ptr<Tile> nextTile = allTiles[y*numCols+x];
    float newEnergy = myProtagonist->getEnergy() - nextTile->getValue();
//    qDebug()<<"newEnergy = "<<newEnergy ;

    // detect map boarder;
    if( x<0 || y<0 || x>=numRows || y>=numCols )
    {
        return true;
    }

    if(mapTiles[nextTile]==1)
    {
        // attack
        for (auto enemy : allEnemies)
        {
            if((enemy->getXPos() == x)&&(enemy->getYPos() == y))
            {
                if(dynamic_cast<PEnemy*>(enemy.get()))
                {
                    myProtagonist->setHealth(myProtagonist->getHealth() - 10);
                    dynamic_cast<PEnemy*>(enemy.get())->poison();
                    mapTiles[nextTile] = 2;
                }
                else if(dynamic_cast<XEnemy*>(enemy.get()))
                {
                    mapTiles[nextTile] = 0;
                    myProtagonist->setHealth(myProtagonist->getHealth() - 5);

                    // pos changed
                    int xdif = x-myProtagonist->getXPos();
                    int ydif = y-myProtagonist->getYPos();
//                    qDebug()<<"dif:: "<<xdif<<ydif;
                    int xnew = x+xdif;
                    int ynew = y+ydif;
                    if(xnew<0 || xnew>=numRows) xnew = numRows/2;
                    if(ynew<0 || ynew>=numCols) ynew = numCols/2;
                    shared_ptr<Tile> t = allTiles[ynew*numCols+xnew];
//                    qDebug()<<"before while: "<<xnew<<ynew;
                    while(mapTiles[t]!=0)
                    {
                        xnew=xnew+xdif;
                        ynew=ynew+ydif;
                        t = allTiles[ynew*numCols+xnew];
                    }
                    mapTiles[t]=1;

//                    qDebug()<<xnew<<ynew;
                    dynamic_cast<XEnemy*>(enemy.get())->attacked(xnew, ynew);
                    if(enemy->getDefeated())
                    {
                        mapTiles[t] = 2;
                    }
                }
                else
                {
                    myProtagonist->setHealth(myProtagonist->getHealth() - 5);
                    enemy->setDefeated(true);
                    mapTiles[nextTile] = 2;
                }
                return true;
            }
        }
    }
    else if(mapTiles[nextTile]==2) return true;
    else if(mapTiles[nextTile]==3)
    {
        myProtagonist->setHealth(myProtagonist->getHealth() - 3);
        emit getPoisoned();
        timerPoison->start(5000);
    }

    myProtagonist->setEnergy(newEnergy);
    return false;
}

shared_ptr<Tile> WorldModel::getTileNearest()
{
    int x = myProtagonist->getXPos();
    int y = myProtagonist->getYPos();

    int minDistance = numCols+numRows;
    shared_ptr<Tile> t = nullptr;

    if(myProtagonist->getHealth()<30)
    {
        for(auto healthpack : allHealthPacks)
        {
            int temp = abs(x-healthpack->getXPos()) + abs(y-healthpack->getYPos());

            if (temp<minDistance)
            {
                minDistance = temp;
                t = allTiles[healthpack->getYPos()*numCols+healthpack->getXPos()];
            }
        }
    }else
    {
        for(auto enemy : allEnemies)
        {
            // pEnemy would not be defeated in lib;
            if (mapTiles[allTiles[enemy->getYPos()*numCols+enemy->getXPos()]] == 2) continue;
            int temp = abs(x-enemy->getXPos()) + abs(y-enemy->getYPos());

            if (temp<minDistance)
            {
                minDistance = temp;
                t = allTiles[enemy->getYPos()*numCols+enemy->getXPos()];
            }
        }
    }

    return t;
}

shared_ptr<Tile> WorldModel::getTileProtagonist()
{
    int x = myProtagonist->getXPos();
    int y = myProtagonist->getYPos();
    shared_ptr<Tile> t = allTiles[y*numCols+x];
    qDebug()<<"prot tile: "<< x<< y;
    return t;
}

void WorldModel::poisonTile()
{
    auto p = dynamic_cast<PEnemy*>(sender());
    int x = p->getXPos();
    int y = p->getYPos();

    int xMin = x-1;
    if(xMin<0) xMin = 0;
    int xMax = x+2;
    if(xMax>numRows) xMax = numRows;
    int yMin = y-1;
    if(yMin<0) yMin = 0;
    int yMax = y+2;
    if(yMax>numCols) yMax = numCols;

    for(int j = yMin; j < yMax; j++)
    {
        bool done = 0;
        for(int i = xMin; i < xMax; i++)
        {
            shared_ptr<Tile> t = allTiles[j*numCols+i];
            if(mapTiles[t])
            {
                // already poisoned
                continue;
            }
            else
            {
                mapTiles[t] = 3;
                emit GDrawPisonedTile(t);
//                qDebug()<<" poisoned: "<< i << ","<< j <<";;"<< mapTiles[t];
                QTimer::singleShot(20000, this, [=] () {poisonRemove(t); });
                done = 1;
                break;
            }
        }
        if(done) break;
    }

}

void WorldModel::poisonRemove(shared_ptr<Tile> t)
{
    mapTiles[t] = 0;
//    qDebug()<< "poison remove pos:"<<t->getXPos()<<","<<t->getYPos();
    emit GRemoveItem(t->getXPos(),t->getYPos());
    //    qDebug()<< "poisonRemove::" << mapTiles[t];
}

vector<shared_ptr<Tile> > WorldModel::getUsed_healthpacks() const
{
    return used_healthpacks;
}



