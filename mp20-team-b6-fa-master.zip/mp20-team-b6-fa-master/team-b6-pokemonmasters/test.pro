QT       += core gui

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++17

# You can make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    GraphicalEnemy.cpp \
    GraphicalWorld.cpp \
    WorldModel.cpp \
    PathFinding.cpp \
    Node.cpp \
    XEnemy.cpp \
    main.cpp \
    mainwindow.cpp \
    textcompleter.cpp \
    textpathfinder.cpp \
    textworldview.cpp \
    textenemy.cpp

HEADERS += \
    GraphicalEnemy.h \
    GraphicalWorld.h \
    WorldModel.h \
    PathFinding.h \
    Node.h \
    XEnemy.h \
    mainwindow.h \
    textpathfinder.h \
    textworldview.h \
    world.h \
    world_global.h \
    textedit.h \
    textenemy.h

FORMS += \
    mainwindow.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target

unix:!macx: LIBS += -L$$PWD/../world_v4/ -lworld

INCLUDEPATH += $$PWD/../world_v4
DEPENDPATH += $$PWD/../world_v4

RESOURCES += \
    resources.qrc
