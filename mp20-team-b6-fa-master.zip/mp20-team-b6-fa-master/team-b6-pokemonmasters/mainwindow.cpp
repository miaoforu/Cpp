﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QStringListModel>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    ui->stackedWidget->setCurrentIndex(0);
    ui->numEnemies->setValue(10);
    ui->numHealthpacks->setValue(10);
    ui->mapBox->addItem("maze1");
    ui->mapBox->addItem("maze2");
    ui->mapBox->addItem("maze3");
    ui->mapBox->addItem("worldmap");
    ui->mapBox->addItem("worldmap4");

    ui->lcdNumber_3->setPalette(Qt::black);
    ui->btn_autoplay->setCheckable(true);

    completingTextEdit = new TextEdit;
    completer = new QCompleter(this);
    completer->setModel(modelFromFile(":/list/wordlist.txt"));
    completer->setModelSorting(QCompleter::CaseInsensitivelySortedModel);
    completer->setCaseSensitivity(Qt::CaseInsensitive);
    completer->setWrapAround(false);
    completingTextEdit->setCompleter(completer);
    completingTextEdit->setUi(ui);
    completingTextEdit->setTextWorld(textWorld);

    ui->completer_container->addWidget(completingTextEdit);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_mapBox_currentIndexChanged(const QString &arg1)
{
    mapName = ":/maps/"+arg1;
    curScene = new QGraphicsScene(this);
    ui->graphicsView->setScene(curScene);
    curScene->addPixmap(QPixmap(mapName).scaled(ui->graphicsView->width(),ui->graphicsView->height(),Qt::KeepAspectRatio));
}

void MainWindow::on_NewStart_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);              //switches from the startpage to the gamepage
    initGame();
    ui->graphicsView_2->setScene(curScene);
    initConnection();
}

void MainWindow::initGame()
{

    worldModel = make_shared<WorldModel>(mapName, ui->numEnemies->value(), ui->numHealthpacks->value());
    //get model data
    auto tiles = worldModel->getAllTiles();
    auto enemies = worldModel->getAllEnemies();
    auto healthpacks = worldModel->getAllHealthPacks();
    auto protagonist = worldModel->getProtagonist();

    path.clear();

    //GRAPHICAL init views
    ui->bar_energy->setValue(protagonist->getEnergy());
    ui->bar_health->setValue(protagonist->getHealth());
    ui->lcdNumber_3->display(ui->numEnemies->value());

    graphicalWorld = make_shared<GraphicalWorld>();
    curScene = graphicalWorld->getScene();//defaut: using a graphic scene
    graphicalWorld->drawWorld(mapName, enemies, healthpacks);

    textWorld = make_shared<TextWorldView>();
    textWorld->initTable(ui->tableWidget, worldModel, ui->help_text_box);

    astar = make_shared<PathFinding>(*worldModel);
    astar->setGWeight(1);
    astar->setHWeight(0.1);
}

void MainWindow::initConnection()
{
    auto p = worldModel->getProtagonist().get();
    connect(p, SIGNAL(posChanged(int, int)), graphicalWorld.get(), SLOT(updateProtagonist(int, int)));
    connect(p, SIGNAL(posChanged(int, int)), textWorld.get(), SLOT(updateProtagonist(int, int)));
    connect(p, SIGNAL(healthChanged(int)), this, SLOT(updateHealth(int)));
    connect(p, SIGNAL(energyChanged(int)), this, SLOT(updateEnergy(int)));
    connect(worldModel.get(), SIGNAL(GRemoveItem(int, int)), graphicalWorld.get(), SLOT(removeItem(int, int)));
    connect(worldModel.get(), SIGNAL(GDrawPisonedTile(shared_ptr<Tile>)), graphicalWorld.get(), SLOT(drawPoisonedTile(shared_ptr<Tile>)));
    connect(worldModel.get(), SIGNAL(getPoisoned()), graphicalWorld.get(), SLOT(drawPoisonedProtagonist()));
    connect(worldModel->getTimerPoison(), SIGNAL(timeout()), graphicalWorld.get(), SLOT(drawProtagonist()));

    connect(worldModel->getProtagonist().get(), SIGNAL(energyChanged(int)), textWorld.get(), SLOT(blinkGreen(int)));
    connect(worldModel->getProtagonist().get(), SIGNAL(healthChanged(int)), textWorld.get(), SLOT(blinkRed(int)));

    for(auto enemy : worldModel->getAllEnemies())
    {
        connect(enemy.get(), SIGNAL(dead()), this, SLOT(decreaseEnemy()));
    }

    pathTimer->setInterval(500);
    connect(pathTimer, SIGNAL(timeout()), this, SLOT(updatePath()));
}



void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if(event->key() == Qt::Key_W)
    {
        worldModel->moveTo(1);
    }
    else if(event->key() == Qt::Key_S)
    {
        worldModel->moveTo(2);
    }
    else if(event->key() == Qt::Key_A)
    {
        worldModel->moveTo(3);
    }
    else if(event->key() == Qt::Key_D)
    {
        worldModel->moveTo(4);
    }
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
//    if(pathTimer->isActive()) event->ignore();

    QPointF pointGraphics = ui->graphicsView_2->mapToScene(event->pos());
    int xClick = pointGraphics.x()/scale -1;
    int yClick = pointGraphics.y()/scale -2;
    qDebug()<<"mouse pressed point is scaled to :"<<xClick<<","<<yClick;

    if(worldModel!=nullptr && xClick>=0 && xClick<worldModel->getRows() && yClick>=0 && yClick<worldModel->getCols())
    {
        auto tiles = worldModel->getAllTiles();
        shared_ptr<Tile> start = worldModel->getTileProtagonist();
        shared_ptr<Tile> end = tiles[yClick*worldModel->getCols() +xClick];
        path = astar->pathFinding(*start,*end);
        showPath(path);
    }
}

void MainWindow::showPath(vector<shared_ptr<Tile> > path)
{
    if(!path.empty())
    {
        for(unsigned int i = 0; i<path.size(); i++)
        {
            auto newX = path[i]->getXPos(); // reversed tiles;
            auto newY = path[i]->getYPos();
            graphicalWorld->changeTileColor(newX,newY, QColor(255,0,0));
        }
        pathTimer->start();
    }
}

void MainWindow::updatePath()
{
    if(!path.empty())
    {
        auto newX = path.back()->getXPos(); // reversed tiles;
        auto newY = path.back()->getYPos();
        graphicalWorld->removeItem(newX,newY);

        if(worldModel->detectEnemy(newX,newY) == 0)
        {
            worldModel->collectHealthpack(newX,newY);
            worldModel->getProtagonist()->setPos(newX,newY);
        }

        path.pop_back(); // remove first tile;
    }
    else
    {
        pathTimer->stop();
        emit autoContinue();
    }
}

void MainWindow::protagonistDie()
{
    QMessageBox::information(this, "You lose!", "Sorry, please start again!");
    ui->stackedWidget->setCurrentIndex(0);
}

void MainWindow::on_btn_switch_clicked()
{
    if(text_view == false){         //if it is a graphical view and you want to switch to a text view

        ui->stackedWidget_2->setCurrentIndex(1);
        text_view = true;
    }
    else{                           //if it is a text view and you want to switch to a graphical view
        ui->stackedWidget_2->setCurrentIndex(0);
        text_view = false;
    }
}

void MainWindow::on_btn_autoplay_clicked(bool checked)
{
    if(checked)
    {
        connect(this, SIGNAL(autoContinue()), this, SLOT(autoplay()));
        connect(this, SIGNAL(autoPlayNewPath(vector<shared_ptr<Tile>>)), textWorld.get(), SLOT(autoPlayDrawPath(vector<shared_ptr<Tile>>)));
        autoplay();
    }else
    {
        disconnect(this, SIGNAL(autoContinue()), this, SLOT(autoplay()));
        disconnect(this, SIGNAL(autoPlayNewPath(vector<shared_ptr<Tile>>)), textWorld.get(), SLOT(autoPlayDrawPath(vector<shared_ptr<Tile>>)));
    }
}

void MainWindow::autoplay()
{
    if(ui->lcdNumber_3->value())
    {
        shared_ptr<Tile> start = worldModel->getTileProtagonist();
        shared_ptr<Tile> end = worldModel->getTileNearest();
        path = astar->pathFinding(*start,*end);
        emit autoPlayNewPath(path);
        showPath(path);
    }

}

void MainWindow::updateHealth(int health)
{
    ui->bar_health->setValue(health);
    if(health < 0)
    {
        protagonistDie();
    }
}

void MainWindow::updateEnergy(int energy)
{
    ui->bar_energy->setValue(energy);
    if(energy <= 0)
    {
        protagonistDie();
    }
}

void MainWindow::decreaseEnemy()
{
    int num = ui->lcdNumber_3->value();
    num--;
//    qDebug()<<"Enemy num decreased;";
    ui->lcdNumber_3->display(num);
    if(num==0){
        QMessageBox::information(this, "You win!", "Congratulations, all enemies died!");
        ui->stackedWidget->setCurrentIndex(0);
    }
    if(ui->btn_autoplay->isChecked())
    {
        worldModel->getProtagonist()->setEnergy(100);
    }
}

void MainWindow::on_btn_newStart_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
    ui->tableWidget->clearContents();
}

void MainWindow::on_btn_pathfind_clicked()
{
    if(worldModel!=nullptr){
        astar->setGWeight(1);
        astar->setHWeight(0.01);
        auto tiles = worldModel->getAllTiles();
        if(tiles.size() > unsigned(1205*worldModel->getCols()+1200)){
            Tile& start = *tiles.at(unsigned(22*worldModel->getCols()));//0,22
            Tile& end = *tiles.at(unsigned(1205*worldModel->getCols()+1200));//1200,1205
            path = astar->pathFinding(start,end);
            QMessageBox::information(this, "Path found", "hooray!");
        }
        else{
            QMessageBox::information(this, "Wrong Map", "Please select the maze map!");
        }
    }
}


QAbstractItemModel *MainWindow::modelFromFile(const QString& fileName)
{
    QFile file(fileName);
    if (!file.open(QFile::ReadOnly))
        return new QStringListModel(completer);

#ifndef QT_NO_CURSOR
    QGuiApplication::setOverrideCursor(QCursor(Qt::WaitCursor));
#endif
    QStringList words;

    while (!file.atEnd()) {
        QByteArray line = file.readLine();
        if (!line.isEmpty())
            words << QString::fromUtf8(line.trimmed());
    }

#ifndef QT_NO_CURSOR
    QGuiApplication::restoreOverrideCursor();
#endif
    return new QStringListModel(words, completer);
}


