#include "PathFinding.h"
// LAMBDAS
auto cost = [](Node& n1, Node& n2){
    float currentValue = (1 - n1.getValue());
    float nextValue = (1 - n2.getValue());
    float cost = nextValue - currentValue;
    return cost < 0 ? 0 : cost ;
};

auto heuristic = [](Node& n1, Node& n2){
    return abs(n1.getX() - n2.getX()) + abs(n1.getY() - n2.getY());
};

// CONSTRUCTOR
PathFinding::PathFinding(WorldModel& world): numCols(world.getCols()), numRows(world.getRows()), gWeight(1), hWeight(1){
    grid = world.getAllTiles();
}
// METHODS
// PATHFINDING
vector<shared_ptr<Tile>> PathFinding::pathFinding(const Tile& start, const Tile& end) const{
    // INITIALIZATION
    vector<shared_ptr<Node>> closedList(unsigned (int (numCols * numRows)), nullptr);
    priority_queue<nodePair, vector<nodePair>, greater<nodePair>> openList;
    vector<shared_ptr<Node>> gridOfNodes(unsigned (int (numCols * numRows)), nullptr);

    shared_ptr<Node> startNode = make_shared<Node>(start);
    shared_ptr<Node> endNode = make_shared<Node>(end);
    startNode->setGivenCost(0);
    startNode->setFinalCost(0);
    gridOfNodes[startNode->getPos(numCols)] = startNode;
    openList.push(make_pair(startNode->getFinalCost(),startNode));

    // ASTAR
    while(!openList.empty()){
        shared_ptr<Node> nodeCurrent = openList.top().second;
        openList.pop();

        if(closedList[nodeCurrent->getPos(numCols)] ==  nodeCurrent){
            continue;
        }
        if(*nodeCurrent == *endNode){
            closedList.push_back(nodeCurrent);
            break;
        }
        for (shared_ptr<Tile> nextTile : findNeighbors(*nodeCurrent)) {
            shared_ptr<Node> next = make_shared<Node>(nextTile);
            float localCost = nodeCurrent->getGivenCost() + cost(*nodeCurrent, *next);
            float globalCost = localCost*gWeight + heuristic(*endNode, *next)*hWeight;
            unsigned int index = getPos(next);
            shared_ptr<Node> nodeNext = gridOfNodes[index];
            if(!nodeNext){
                nodeNext = make_shared<Node>(nextTile);
                nodeNext->setGivenCost(localCost);
                nodeNext->setFinalCost(globalCost);
                nodeNext->setParent(nodeCurrent);
            }else if (localCost < nodeNext->getGivenCost()) {
                nodeNext->setGivenCost(localCost);
                nodeNext->setFinalCost(globalCost);
                nodeNext->setParent(nodeCurrent);
            }
            if(closedList[index]){
                if(compareTwoNodes(closedList[index], nodeNext)){
                    continue;
                }
            }
            openList.push(make_pair(nodeNext->getFinalCost(), nodeNext));
        }
        closedList[nodeCurrent->getPos(numCols)] = nodeCurrent;
    }
    //RECONSTRUCT
    return reconstructPath(closedList, startNode);
}

unsigned int PathFinding::getPos(const shared_ptr<Node> &node) const{
    return node->getPos(numCols);
}

vector<shared_ptr<Tile>> PathFinding::findNeighbors(const Node & node) const{
    vector<shared_ptr<Tile>> neighbors;
    unsigned int position = node.getPos(numCols);
    unsigned int up = position - unsigned(numCols);
    unsigned int down = position + unsigned(numCols);
    int x = node.getX();
    int y = node.getY();
    if(x > 0){
        neighbors.push_back(grid.at(position - 1));
        if(y > 0){
            neighbors.push_back(grid.at(up - 1));
        }
        if(y < numRows-1){
            neighbors.push_back(grid.at(down - 1));
        }
    }
    if(x < numCols-1){
        neighbors.push_back(grid.at(position + 1));
        if(y > 0){
            neighbors.push_back(grid.at(up + 1));
        }
        if(y < numRows-1){
            neighbors.push_back(grid.at(down + 1));
        }
    }
    if(y > 0){
        neighbors.push_back(grid.at(up));
    }
    if(y < numRows-1){
        neighbors.push_back(grid.at(down));
    }
    return neighbors;
}

void PathFinding::setGWeight(float gWeight){
    this->gWeight = gWeight;
}

void PathFinding::setHWeight(float hWeight){
    this->hWeight = hWeight;
}
// FUNCTIONS
bool compareTwoNodes(shared_ptr<Node> n1, shared_ptr<Node> n2){
    return n1->getFinalCost() < n2->getFinalCost();
}
vector<shared_ptr<Tile>> reconstructPath(vector<shared_ptr<Node>> closedList,shared_ptr<Node> startNode){
    vector<shared_ptr<Tile>> path;
    shared_ptr<Node> next = closedList.back();
    while(!(*next == *startNode)){
        path.push_back(next->getTile());
        next = next->getParent();
    }
    path.push_back(startNode->getTile());
    return path;
}
