#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGridLayout>
#include <QGraphicsScene>
#include <QMessageBox>
#include <QKeyEvent>
#include <QMouseEvent>
#include <QDebug>
#include <iostream>
#include <math.h>
#include "WorldModel.h"
#include "GraphicalWorld.h"
#include "textworldview.h"
#include "textedit.h"
#include "textpathfinder.h"


using namespace std;

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void read_input();

private:
    Ui::MainWindow *ui;
    QGraphicsScene *curScene;
    QString mapName;
    shared_ptr<WorldModel> worldModel;
    shared_ptr<GraphicalWorld> graphicalWorld;
    shared_ptr<TextWorldView> textWorld;
    shared_ptr<PathFinding> astar;
    vector<shared_ptr<Tile>> path;
    bool text_view = 0;
    shared_ptr<TextPathFinder> textPathFinder;

    QAbstractItemModel *modelFromFile(const QString& fileName);
    QCompleter *completer = nullptr;
    TextEdit *completingTextEdit;

    void initGame();
    void initConnection();
    void keyPressEvent(QKeyEvent *event);
    void mousePressEvent(QMouseEvent *event);

    QTimer* pathTimer = new QTimer();
    void showPath(vector<shared_ptr<Tile>> path);

    void protagonistDie();

signals:
    void autoContinue();
    void autoPlayNewPath(vector<shared_ptr<Tile>>);

private slots:
    void on_NewStart_clicked();
    void on_mapBox_currentIndexChanged(const QString &arg1);
    void on_btn_newStart_clicked();
    void on_btn_pathfind_clicked();
    void on_btn_switch_clicked();
    void on_btn_autoplay_clicked(bool checked);
    void autoplay();

    void updateHealth(int health);
    void updateEnergy(int energy);
    void decreaseEnemy();
    void updatePath();


};

//void findPath(int x, int y, shared_ptr<PathFinding> aStar, vector<shared_ptr<Tile>> path, std::shared_ptr<WorldModel> worldModel, QTableWidget * text_table);
//void updatePathText(vector<shared_ptr<Tile>> path, std::shared_ptr<WorldModel> worldModel, QTableWidget * text_table, QTimer * pathTimerTwo);

#endif // MAINWINDOW_H
