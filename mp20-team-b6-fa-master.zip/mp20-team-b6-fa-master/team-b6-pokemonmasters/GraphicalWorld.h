#ifndef GRAPHICALVIEW_H
#define GRAPHICALVIEW_H

#include "world.h"
#include "ui_mainwindow.h"
#include "WorldModel.h"
#include <QGraphicsView>
#include <QGraphicsPixmapItem>
#include "GraphicalEnemy.h"

#define scale 30

using namespace std;

class GraphicalWorld : public QObject
{
    Q_OBJECT
public:
    GraphicalWorld();
    ~GraphicalWorld();

    void drawWorld(QString filename, vector<shared_ptr<Enemy>> &enemies, vector<shared_ptr<Tile>> &healthpacks);
    void drawBackground(QString filename);
    void drawEnemies(vector<shared_ptr<Enemy>> &enemies);
    void drawHealthPacks(vector<shared_ptr<Tile>> &healthpacks);

    QGraphicsScene *getScene();
    QGraphicsPixmapItem *getProtagonistView();
    int getScale();
    void changeTileColor(int x, int y, QColor color);

public slots:
    void removeItem(int x, int y);
    void updateProtagonist(int x, int y);
//    void updateXEnemy(int x, int y);
    void drawPoisonedProtagonist();
    void drawProtagonist();
    void drawPoisonedTile(shared_ptr<Tile> t);
//    void deadEnemy(int x, int y);

//    void messageDie();


private:
    QGraphicsScene *worldScene;
    QGraphicsPixmapItem *backgroundView;
    QGraphicsPixmapItem *protagonistView;
};

#endif // GRAPHICALVIEW_H
