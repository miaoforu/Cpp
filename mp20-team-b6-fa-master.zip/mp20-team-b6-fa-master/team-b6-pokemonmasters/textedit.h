#ifndef TEXTEDIT_H
#define TEXTEDIT_H

#include <QMainWindow>
#include <QTextEdit>
#include <QCompleter>
#include <ui_mainwindow.h>
#include "textworldview.h"

class TextEdit : public QTextEdit
{
    Q_OBJECT

public:
    TextEdit(QWidget *parent = nullptr);
    ~TextEdit();

    void setCompleter(QCompleter *c);
    void setUi(Ui::MainWindow * ui);
    void setTextWorld(shared_ptr<TextWorldView> textworld);

    QCompleter *completer() const;


protected:
    void keyPressEvent(QKeyEvent *e) override;
    void focusInEvent(QFocusEvent *e) override;


private slots:
    void insertCompletion(const QString &completion);

private:
    QString textUnderCursor() const;
    QCompleter *c = nullptr;
    shared_ptr<TextWorldView> textWorld;
    Ui::MainWindow * ui;

};

#endif // TEXTEDIT_H
