#include "XEnemy.h"
#include <QDebug>

XEnemy::XEnemy(int xPosition, int yPosition, float strength):
    Enemy(xPosition, yPosition, strength)
{

}

void XEnemy::attacked(int x,int y)
{
    timesAttacked++;
    this->setXPos(x);
    this->setYPos(y);
    emit positionUpdated(x, y);
    emit positionUpdatedTwo(x, y, timesAttacked);
//    qDebug()<<"attacked, newpos: "<< x<< y;
    if (timesAttacked==3) setDefeated(true);
}
