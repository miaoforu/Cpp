#include "textworldview.h"
#include <QHeaderView>
#include <QTableWidget>
#include <QDebug>
#include <iostream>
#include <sstream>
#include "textenemy.h"
#include <cmath>
#include <unistd.h>
//#include "PathFinding.h"
#include "mainwindow.h"
#include "textpathfinder.h"

vector<shared_ptr<Tile>> tiles;
shared_ptr<Protagonist> protagonist;
vector<shared_ptr<Enemy>> enemies;
vector<shared_ptr<Tile>> healthpacks;
QTableWidget * text_table;
QTextBrowser * help_text_box;
std::shared_ptr<WorldModel> worldModel;
int protagonistXpos;
int protagonistYpos;
shared_ptr<PathFinding> aStar;
vector<shared_ptr<Tile>> path;
std::shared_ptr<TextPathFinder> textPathFinder;

TextWorldView::TextWorldView()
{

}

TextWorldView::~TextWorldView(){

}


void TextWorldView::initTable(QTableWidget* text_table_t, std::shared_ptr<WorldModel> worldModel_t, QTextBrowser * help_text_box_t){


    worldModel = worldModel_t;

    tiles = worldModel_t->getAllTiles();
    enemies = worldModel_t->getAllEnemies();
    healthpacks = worldModel_t->getAllHealthPacks();
    protagonist = worldModel_t->getProtagonist();
    text_table = text_table_t;

    path.clear();
    aStar = make_shared<PathFinding>(*worldModel);
    textPathFinder = make_shared<TextPathFinder>();
    textPathFinder->init(aStar, path, worldModel, text_table);

    protagonist->getYPos();

    help_text_box = help_text_box_t;
    help_text_box->setVisible(false);



    setupTable(worldModel_t);
    drawEnemies(text_table);
    drawHealthPacks(text_table);


}

void TextWorldView::setupTable(std::shared_ptr<WorldModel> worldModel){

    protagonist->getYPos();

    text_table->setRowCount(worldModel->getRows());
    text_table->setColumnCount(worldModel->getCols());

    text_table->horizontalHeader()->setDefaultSectionSize(50);
    text_table->verticalHeader()->setDefaultSectionSize(50);
    text_table->horizontalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    text_table->verticalHeader()->setSectionResizeMode(QHeaderView::Fixed);
    for( int row = 0; row < worldModel->getRows(); row++ )
    {
        for( int column = 0; column < worldModel->getCols(); column++ )
        {
//            text_table->setItem(0, 0, new QTableWidgetItem("qsdfqsdjfmqksdfmjsqkdfjmqsldkfjmqlfjlkmsqldkjqmsdkfjmlqfkjldsqf"));
        }
    }


    text_table->setItem(0, 0, new QTableWidgetItem("P"));

}

void TextWorldView::drawEnemies(QTableWidget* text_table){
    for(auto &enemy : enemies){

        if(dynamic_cast<PEnemy*>(enemy.get())){
            text_table->setItem(enemy->getYPos(), enemy->getXPos(), new QTableWidgetItem("PE"));
        }
        else{
            if(dynamic_cast<XEnemy*>(enemy.get())){
                text_table->setItem(enemy->getYPos(), enemy->getXPos(), new QTableWidgetItem("XE"));
                connect(enemy.get(), SIGNAL(positionUpdatedTwo(int, int, int)), this, SLOT(updateXEnemy(int, int, int)));
            }
            else{
                text_table->setItem(enemy->getYPos(), enemy->getXPos(), new QTableWidgetItem("E"));
            }
        }

        TextEnemy* textEnemy = new TextEnemy(enemy);
        connect(enemy.get(), SIGNAL(dead()), textEnemy, SLOT(showDeadEnemy()));
        connect(textEnemy, SIGNAL(enemyIsKilled(int, int, int)), this, SLOT(showEnemyDead(int, int, int)));

    }
}

void TextWorldView::drawHealthPacks(QTableWidget * text_table){
    for(auto &healthpack : healthpacks){
        text_table->setItem(healthpack->getYPos(), healthpack->getXPos(), new QTableWidgetItem("HP"));
    }

}

void TextWorldView::process_input(QString inputstring){

    std::cout << "reading input string" << std::endl;

    if(inputstring == QString::fromStdString("up")){
        if(protagonist->getXPos()>0){
            worldModel->moveTo(1);
        }
    }

    if(inputstring == QString::fromStdString("down")){
        if(protagonist->getXPos()<text_table->rowCount()-1){
            worldModel->moveTo(2);
        }
    }

    if(inputstring == QString::fromStdString("left")){
        if(protagonist->getYPos()>0){
            worldModel->moveTo(3);
        }
    }

    if(inputstring == QString::fromStdString("right")){
        if(protagonist->getYPos()<text_table->columnCount()-1){
            worldModel->moveTo(4);
        }
    }

    if(inputstring == QString::fromStdString("help")){
        std::cout << "outputting help" << std::endl;

        help_text_box->setVisible(true);
        help_text_box->setPlainText("The available commands are: right, left, up, down, help, attack nearest enemy, take nearest health pack, goto x y.");

    }

    if(inputstring.contains("goto")){
        if(inputstring == QString::fromStdString("goto x y")){
            help_text_box->setVisible(true);
            help_text_box->setPlainText("Please enter the wanted x and y coordinate.");
        }
        else{
            //parsing x and y to call the pathfinding function
            std::stringstream stringstream_t;
            stringstream_t << inputstring.toStdString();
            std::string string_temp;
            int found;
            std::vector<int> koek;

            while (!stringstream_t.eof()) {
                stringstream_t >> string_temp;
                if (stringstream(string_temp) >> found){
//                    cout << found << " ";
                    koek.push_back(found);
                }
                string_temp = "";
            }

            int y = koek.back();
            koek.pop_back();
            int x = koek.back();
//            std::cout << "x:" << x << " y:" << y << std::endl;


            if(x<1 || y<1 || x > worldModel->getRows() || y > worldModel->getCols()){
                help_text_box->setVisible(true);
                help_text_box->setPlainText("You have entered these coordinates: x:" + QString::number(x) + " y: " +QString::number(y) + " these are not part of the playing field!");
            }
            else{
                help_text_box->setVisible(true);
                help_text_box->setPlainText("You have entered these coordinates: x:" + QString::number(x) + " y: " +QString::number(y));
                textPathFinder->findPath(x-1, y-1);
            }

            //PATHFIND

//            aStar = make_shared<PathFinding>(*worldModel);

//            aStar->setGWeight(1);
//            aStar->setHWeight(0.01);

//            unsigned int position_path_start = protagonistYpos*worldModel->getCols()+protagonistXpos;
//            unsigned int position_path_end = (y)*worldModel->getCols()+x;

//            shared_ptr<Tile> start_tile = tiles[position_path_start];
//            shared_ptr<Tile> end_tile = tiles[position_path_end];

//            std::cout << 4 << std::endl;
//            path = aStar->pathFinding(*start_tile, *end_tile);
//            std::cout << 5 << std::endl;


//            if(!path.empty()){
//                auto newX = path.front()->getXPos();
//                auto newY = path.front()->getYPos();
//                worldModel->getProtagonist()->setPos(newX, newY);
//                qDebug()<<newX<<newY;
//            }

        }
    }


    if(inputstring == QString::fromStdString("attack nearest enemy")){

        shared_ptr<Enemy> current_enemy = enemies[0];

        int delta_x_cur;
        int delta_y_cur;
        int delta_x_temp;
        int delta_y_temp;

        for(auto enemy : enemies){

            delta_x_cur = protagonistYpos - current_enemy->getYPos();
            delta_y_cur = protagonistXpos - current_enemy->getXPos();
            delta_x_temp = protagonistYpos - enemy->getYPos();
            delta_y_temp = protagonistXpos - enemy->getXPos();

            int distance_cur = sqrt(pow(delta_x_cur, 2) + pow(delta_y_cur, 2));
            int distance_temp = sqrt(pow(delta_x_temp, 2) + pow(delta_y_temp, 2));

            if(distance_cur == distance_temp){

                srand( time( NULL ) );
                float random_number = rand() % 100 + 1;
                std::cout << "random number: " << random_number << std::endl;

                if(random_number < 50){
                    if(dynamic_cast<PEnemy*>(enemy.get())){
                        if(dynamic_cast<PEnemy*>(enemy.get())->getPoisonLevel() != 0){
                            current_enemy = enemy;
                        }
                    }
                    else{
                        if(enemy->getDefeated()== false){
                            current_enemy = enemy;
                        }
                    }
                }
            }
            else{
                if(distance_temp < distance_cur){
                    if(dynamic_cast<PEnemy*>(enemy.get())){
                        if(dynamic_cast<PEnemy*>(enemy.get())->getPoisonLevel() != 0){
                            current_enemy = enemy;
                        }
                    }
                    else{
                        if(enemy->getDefeated()== false){
                            current_enemy = enemy;
                        }
                    }
                }
            }
        }

        //PATHFINDER

        textPathFinder->findPath(current_enemy->getXPos(), current_enemy->getYPos());

        //! this is only a temporary solution, enemies should be deactivated or moved from the field (like here) when they are killed
        //! because otherwise they will still exist if you kill them via move commands in the text view or keys in the graphical view
//        current_enemy->setXPos(-1000);
//        current_enemy->setYPos(-1000);

    }

    if(inputstring == QString::fromStdString("take nearest health pack")){

        shared_ptr<Tile> current_healthpack = healthpacks[0];

        int delta_x_cur;
        int delta_y_cur;
        int delta_x_temp;
        int delta_y_temp;

//        if(worldModel->getUsed_healthpacks().empty() == false){
//        std::cout << worldModel->getUsed_healthpacks().back()->getXPos() << std::endl;
//        std::cout << worldModel->getUsed_healthpacks().back()->getYPos() << std::endl;
//        }

        for(auto healthpack : healthpacks){

            delta_x_cur = protagonistYpos - current_healthpack->getYPos();
            delta_y_cur = protagonistXpos - current_healthpack->getXPos();
            delta_x_temp = protagonistYpos - healthpack->getYPos();
            delta_y_temp = protagonistXpos - healthpack->getXPos();

            int distance_cur = sqrt(pow(delta_x_cur, 2) + pow(delta_y_cur, 2));
            int distance_temp = sqrt(pow(delta_x_temp, 2) + pow(delta_y_temp, 2));

            bool is_used = false;
            bool free_pass = false;

            if(worldModel->getUsed_healthpacks().empty() == true){
                is_used = false;
            }
            else{
                std::vector<std::shared_ptr<Tile>> used_healthpacks = worldModel->getUsed_healthpacks();
                for(std::vector<std::shared_ptr<Tile>>::iterator it = used_healthpacks.begin(); it != used_healthpacks.end(); ++it) {
                    if(it->get()->getXPos() == healthpack->getXPos() && it->get()->getYPos() == healthpack->getYPos()){
                        is_used = true;
                    }
                    if(it->get()->getXPos() == current_healthpack->getXPos() && it->get()->getYPos() == current_healthpack->getYPos()){
                        free_pass = true;
                    }
                }
            }

            if(is_used == false){
                if(distance_cur == distance_temp){

                    srand( time( NULL ) );
                    float random_number = rand() % 100 + 1;
                    std::cout << "random number: " << random_number << std::endl;

                    if(random_number < 50){
                        current_healthpack = healthpack;
                    }
                }
                else{
                    if(distance_temp < distance_cur  || free_pass == true){
                        current_healthpack = healthpack;
                    }
                }
            }
        }

        textPathFinder->findPath(current_healthpack->getXPos(), current_healthpack->getYPos());



        // !! here you tried to do the movement to the healthpack yourself, but you ran into trouble when the protagonist reaches an enemy on its way
        // THEN I realised that this part should be done by the PATHFINDER. Your task is to choose which healthpack to go to (which you did above here)
        // It is the pathfinder's task to actually go to it.

//        int move_in_xdirection = current_healthpack->getXPos() - protagonistXpos;
//        int move_in_ydirection = current_healthpack->getYPos() - protagonistYpos;

//        if(move_in_xdirection > 0){
//            while(move_in_xdirection != 0){
//                process_input("right");
//                move_in_xdirection--;
//            }
//        }
//        else{
//            while(move_in_xdirection != 0){
//                process_input("left");
//                move_in_xdirection++;
//            }
//        }
//        if(move_in_ydirection > 0){
//            while(move_in_ydirection != 0){
//                process_input("down");
//                move_in_ydirection--;
//            }
//        }
//        else{
//            while(move_in_ydirection != 0){
//                process_input("up");
//                move_in_ydirection++;
//            }
//        }

        //! this is only a temporary solution, healthpacks should be deactivated or moved from the field (like here) when they are taken
        //! because otherwise they will still exist if you kill them via move commands in the text view or keys in the graphical view
//        current_healthpack->setXPos(-1000);
//        current_healthpack->setYPos(-1000);

    }

}

void TextWorldView::updateProtagonist(int x, int y)
{
    text_table->setItem(protagonistYpos, protagonistXpos, new QTableWidgetItem(" "));
    protagonistXpos = x;
    protagonistYpos = y;
    text_table->setItem(protagonistYpos, protagonistXpos, new QTableWidgetItem("P"));

}

void TextWorldView::showEnemyDead(int x, int y, int type){

    if(type == 1){
        text_table->setItem(y, x, new QTableWidgetItem("D-PE"));
    }
    else{
        if(type == 2){

        }
        else{
            text_table->setItem(y, x, new QTableWidgetItem("D-E"));
        }
    }

}

void TextWorldView::updateXEnemy(int x, int y, int timesAttacked){

    QString element = "XE";

    if(timesAttacked == 3){
        element = "D-XE";
    }

    int tempx = x - protagonistXpos;
    int tempy = y - protagonistYpos;

    if(x == protagonistXpos){
        if(protagonistYpos>y){
            tempy = tempy + 2;
            text_table->setItem(y+tempy+1, x , new QTableWidgetItem(" "));
            text_table->setItem(y+tempy, x , new QTableWidgetItem(element));
        }
        if(protagonistYpos<y){
            tempy = tempy - 2;
            text_table->setItem(y+tempy-1, x , new QTableWidgetItem(" "));
            text_table->setItem(y+tempy, x , new QTableWidgetItem(element));
        }
    }
    if(y == protagonistYpos){
        if(protagonistXpos>x){
            tempx = tempx + 2;
            text_table->setItem(y, x+tempx+1 , new QTableWidgetItem(" "));
            text_table->setItem(y, x+tempx , new QTableWidgetItem(element));
        }
        if(protagonistXpos<x){
            tempx = tempx - 2;
            text_table->setItem(y, x+tempx-1 , new QTableWidgetItem(" "));
            text_table->setItem(y, x+tempx , new QTableWidgetItem(element));
        }
    }
}

void TextWorldView::autoPlayDrawPath(vector<shared_ptr<Tile>> path){
    textPathFinder->drawPath(path);
}


void TextWorldView::blinkGreen(int a){

//    QTableWidgetItem item = QTableWidgetItem("AAAAAAAAAAAAAAAAAAAAAAAAAAAA");
//    item.setForeground(QBrush(QColor(0, 255, 0)));
//    text_table->setItem(protagonistYpos, protagonistXpos, &item);

//    text_table->setItem(protagonistYpos, protagonistXpos, new QTableWidgetItem("P"));

}

void TextWorldView::blinkRed(int a){
//    QTableWidgetItem item = QTableWidgetItem("AAAAAAAAAAAAAAAAAAAAAa");
//    item.setForeground(QBrush(QColor(255, 0, 0)));
//    text_table->setItem(protagonistYpos, protagonistXpos, &item);

//    text_table->setItem(protagonistYpos, protagonistXpos, new QTableWidgetItem("P *"));

}

































