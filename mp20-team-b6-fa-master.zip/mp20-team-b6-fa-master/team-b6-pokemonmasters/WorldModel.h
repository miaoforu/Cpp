#ifndef WorldModel_H
#define WorldModel_H

#include "world.h"
#include "XEnemy.h"
#include <iostream>
#include <vector>
#include <QTimer>
#include <map>
#include <cmath>

using namespace std;

class WorldModel : public QObject
{
    Q_OBJECT
public:
    WorldModel(QString filename, unsigned int nrOfEnemies, unsigned int nrOfHealthpacks);

    vector<shared_ptr<Tile>> getAllTiles();
    vector<shared_ptr<Enemy>> getAllEnemies();
    vector<shared_ptr<Tile>> getAllHealthPacks();
    shared_ptr<Protagonist> getProtagonist();
    shared_ptr<World> getWorld();
    int getNumEnemies() const;
    int getRows() const;
    int getCols() const;
    QTimer *getTimerPoison();
    int getMapValue(shared_ptr<Tile> tile);

    void moveTo(int direction);
    void collectHealthpack(int x, int y);
    bool detectEnemy(int x, int y);
    shared_ptr<Tile> getTileNearest();
    shared_ptr<Tile> getTileProtagonist();

    void initialMapTiles();
    void createXEnemies(int num);

    vector<shared_ptr<Tile> > getUsed_healthpacks() const;

public slots:
    void poisonTile();
    void poisonRemove(shared_ptr<Tile> t);

signals:
    void GRemoveItem(int x, int y);
    void GDrawPisonedTile(shared_ptr<Tile> t);
    void getPoisoned();

private:
    shared_ptr<World> curWorld;                                                 //this is the world instance from the library which initializes the game
    shared_ptr<Protagonist> myProtagonist;                                     //this stores the reference of the protagonist
    vector<shared_ptr<Tile>> allTiles;                                          //this stores all reference to tiles
    vector<shared_ptr<Enemy>> allEnemies;                                       //this stores all reference to enemies including P
    vector<shared_ptr<Tile>> allHealthPacks;                                    //this stores all reference to health packs
    int numEnemies;                                                             //number of enemies
    int numRows;                                                                   //number of rows
    int numCols;                                                                   //number of cols

    vector<shared_ptr<Tile>> used_healthpacks;

    map<shared_ptr<Tile>, int> mapTiles;    // 1==living; 2==defeated; 3==poison; 4==healthpack
    QTimer *timerPoison = new QTimer(this);
};

#endif // WorldModel_H
