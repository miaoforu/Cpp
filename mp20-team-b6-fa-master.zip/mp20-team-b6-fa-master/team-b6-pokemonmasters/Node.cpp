#include "Node.h"
Node::Node(const shared_ptr<Tile> tile) : tile(tile), givenCost(0), finalCost(0){
}
Node::Node(const Tile& tile) : tile(make_shared<Tile>(tile)), givenCost(0), finalCost(0){
}
shared_ptr<Tile> Node::getTile() const{
    return this->tile;
}
float Node::getValue() const{
    return tile->getValue();
}
unsigned int Node::getPos(const int numCols) const{
    return unsigned(this->getY() * numCols + this->getX());
}
int Node::getX() const{
    return tile->getXPos();
}
int Node::getY() const{
    return tile->getYPos();
}
float Node::getGivenCost() const{
    return this->givenCost;
}
void Node::setGivenCost(float cost){
    this->givenCost = cost;
}
float Node::getFinalCost() const{
    return this->finalCost;
}
void Node::setFinalCost(float cost){
    this->finalCost = cost;
}
shared_ptr<Node> Node::getParent() const{
    return parentNode;
}
void Node::setParent(shared_ptr<Node> parent){
    this->parentNode = parent;
}
bool Node::operator== (const Node & other) const{
    return (getX() == other.getX()) && (getY() == other.getY());
}
bool operator< (const Node& a, const Node& b){
    return a.getFinalCost() > b.getFinalCost();
}
