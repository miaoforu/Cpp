#ifndef TEXTWORLDVIEW_H
#define TEXTWORLDVIEW_H

#include <QTableWidget>
#include <QMainWindow>
#include <QGridLayout>
#include <QTextEdit>
#include <QTextBrowser>
#include "PathFinding.h"
#include "textpathfinder.h"

class TextWorldView : public QObject
{
    Q_OBJECT

public:
    void drawEnemies(QTableWidget* text_table);
    void drawHealthPacks(QTableWidget * text_table);
    void setupTable(std::shared_ptr<WorldModel> worldModel);
    void process_input(QString inputstring);

    TextWorldView();
    ~TextWorldView();

    void initTable(QTableWidget* text_table, std::shared_ptr<WorldModel> worldModel, QTextBrowser * help_text_box);




public slots:
    void updateProtagonist(int x, int y);
    void showEnemyDead(int x, int y, int type);
    void updateXEnemy(int x, int y, int timesAttacked);
    void autoPlayDrawPath(vector<shared_ptr<Tile>>);
    void blinkRed(int);
    void blinkGreen(int);

};

#endif // TEXTWORLDVIEW_H
