#ifndef MP20_TEAM_B6_FA_NODE_H
#define MP20_TEAM_B6_FA_NODE_H

#include "WorldModel.h"
#include "world.h"
#include "world_global.h"

using namespace std;

class Node
{
public:
    Node(const shared_ptr<Tile> tile);
    Node(const Tile& tile);
    shared_ptr<Tile> getTile() const;
    float getValue() const;
    unsigned int getPos(const int numCols) const;
    int getX() const;
    int getY() const;
    float getGivenCost() const;
    void setGivenCost(float cost);
    float getFinalCost() const;
    void setFinalCost(float cost);
    shared_ptr<Node> getParent() const;
    void setParent(shared_ptr<Node> parent);
    bool operator== (const Node & other) const;


private:
    const shared_ptr<Tile> tile;
    float givenCost;
    float finalCost;
    shared_ptr<Node> parentNode;
};

bool operator< (const Node& a, const Node& b);

#endif //MP20_TEAM_B6_FA_NODE_H
