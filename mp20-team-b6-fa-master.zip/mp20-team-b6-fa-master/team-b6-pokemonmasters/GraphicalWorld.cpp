#include "GraphicalWorld.h"
#include <QDebug>

GraphicalWorld::GraphicalWorld()
{
    worldScene = new QGraphicsScene();
}

GraphicalWorld::~GraphicalWorld()
{

}

void GraphicalWorld::drawWorld(QString filename, vector<shared_ptr<Enemy> > &enemies, vector<shared_ptr<Tile> > &healthpacks)
{
    drawBackground(filename);
    drawEnemies(enemies);
    drawHealthPacks(healthpacks);

    protagonistView = new QGraphicsPixmapItem(QPixmap(":/icons/Protagonist").scaled(scale,scale));
    worldScene->addItem(protagonistView);
    protagonistView->setPos(QPoint(0,0));
}

void GraphicalWorld::drawBackground(QString filename)
{
    backgroundView = new QGraphicsPixmapItem(QPixmap(filename));
    backgroundView->setScale(scale);
    worldScene->addItem(backgroundView);
}

void GraphicalWorld::drawEnemies(vector<shared_ptr<Enemy> > &enemies)
{
    for(auto &enemy : enemies)
    {
        GraphicalEnemy* graphicalEnemy = new GraphicalEnemy(enemy, worldScene, scale);
        connect(enemy.get(), SIGNAL(dead()), graphicalEnemy, SLOT(showDeadEnemy()));
    }
}

void GraphicalWorld::drawHealthPacks(vector<shared_ptr<Tile> > &healthpacks)
{
    for(auto &healthpack : healthpacks)
    {
        QGraphicsPixmapItem* item = new QGraphicsPixmapItem(QPixmap(":/icons/HealthPack").scaled(scale,scale));
        item->setPos(healthpack->getXPos()*scale,healthpack->getYPos()*scale);
        worldScene->addItem(item);
    }
}

void GraphicalWorld::drawProtagonist()
{
    protagonistView->setPixmap(QPixmap(":/icons/Protagonist").scaled(scale,scale));
}

QGraphicsScene *GraphicalWorld::getScene()
{
    return worldScene;
}

QGraphicsPixmapItem *GraphicalWorld::getProtagonistView()
{
    return protagonistView;
}

int GraphicalWorld::getScale()
{
    return scale;
}

void GraphicalWorld::changeTileColor(int x, int y, QColor color)
{
    QBrush brush(color, Qt::Dense4Pattern);
    QPen pen(brush, 0, Qt::SolidLine,  Qt::SquareCap, Qt::BevelJoin );
    worldScene->addRect(x*scale, y*scale, scale, scale, pen, brush);
}

void GraphicalWorld::updateProtagonist(int x, int y)
{
    protagonistView->setPos(QPoint(x*scale, y*scale));
}

void GraphicalWorld::drawPoisonedProtagonist()
{
    protagonistView->setPixmap(QPixmap(":/icons/Hurt").scaled(scale,scale));
}

void GraphicalWorld::drawPoisonedTile(shared_ptr<Tile> t)
{
    changeTileColor(t->getXPos(),t->getYPos(),QColor(180,0,180));
}

void GraphicalWorld::removeItem(int x, int y)
{
    Qt::ItemSelectionMode mode = Qt::IntersectsItemBoundingRect;
    Qt::SortOrder order = Qt::DescendingOrder;
    const QTransform &deviceTransform = QTransform();
    auto hp = worldScene->items(QPointF(x*scale, y*scale), mode, order, deviceTransform);
    worldScene->removeItem(hp.at(0));
}
