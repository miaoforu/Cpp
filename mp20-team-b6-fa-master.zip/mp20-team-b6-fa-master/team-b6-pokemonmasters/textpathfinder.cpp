#include "textpathfinder.h"


TextPathFinder::TextPathFinder()
{

}


void TextPathFinder::init(shared_ptr<PathFinding> astar_t, vector<shared_ptr<Tile>> path_t, std::shared_ptr<WorldModel> worldModel_t, QTableWidget * text_table_t){
    astar = astar_t;
    path = path_t;
    worldModel = worldModel_t;
    text_table = text_table_t;
}

void TextPathFinder::findPath(int x, int y){

    if(worldModel!=nullptr){
        astar->setGWeight(1);
        astar->setHWeight(0.1);
        auto tiles = worldModel->getAllTiles();
        int xProt = worldModel->getProtagonist()->getXPos();
        int yProt = worldModel->getProtagonist()->getYPos();
        shared_ptr<Tile> start = tiles[yProt*worldModel->getCols() +xProt];
        shared_ptr<Tile> end = tiles[y*worldModel->getCols() +x];
        path = astar->pathFinding(*start,*end);

        if(!path.empty())
        {
            for(unsigned int i = 1; i<path.size()-1; i++)
            {
                auto newX = path[i]->getXPos(); // reversed tiles;
                auto newY = path[i]->getYPos();

                text_table->setItem(newY, newX, new QTableWidgetItem("+"));

            }

            connect(pathTimerTwo, SIGNAL(timeout()), this, SLOT(updatePathText()));

            pathTimerTwo->setInterval(500);
            pathTimerTwo->start();

        }

    }

}

void TextPathFinder::updatePathText(){

    if(!path.empty()){

        auto newX = path.back()->getXPos();
        auto newY = path.back()->getYPos();

        if (worldModel->detectEnemy(newX, newY)){

        } else {
            worldModel->collectHealthpack(newX, newY);
            text_table->setItem(newY, newX, new QTableWidgetItem("P"));
            worldModel->getProtagonist()->setPos(newX,newY);
        }

        path.pop_back(); // remove first tile;
    }
    else{
        pathTimerTwo->stop();
    }
}

void TextPathFinder::drawPath(vector<shared_ptr<Tile> > path){
    for(unsigned int i = 1; i<path.size()-1; i++)
    {
        auto newX = path[i]->getXPos(); // reversed tiles;
        auto newY = path[i]->getYPos();

        text_table->setItem(newY, newX, new QTableWidgetItem("+"));

    }

}








