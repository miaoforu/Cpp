#ifndef TEXTPATHFINDER_H
#define TEXTPATHFINDER_H
#include "textworldview.h"

class TextPathFinder: public QObject
{
    Q_OBJECT
public:
    TextPathFinder();
    void init(shared_ptr<PathFinding> astar, vector<shared_ptr<Tile>> path, std::shared_ptr<WorldModel> worldModel, QTableWidget * text_table);
    void findPath(int x, int y);
    void drawPath(vector<shared_ptr<Tile>> path);

private:
    shared_ptr<PathFinding> astar;
    vector<shared_ptr<Tile>> path;
    std::shared_ptr<WorldModel> worldModel;
    QTableWidget * text_table;
    QTimer* pathTimerTwo = new QTimer();

private slots:
    void updatePathText();
};

#endif // TEXTPATHFINDER_H
