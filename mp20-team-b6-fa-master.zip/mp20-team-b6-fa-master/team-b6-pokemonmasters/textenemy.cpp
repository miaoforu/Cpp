#include "textenemy.h"
#include "mainwindow.h"



TextEnemy::TextEnemy(std::shared_ptr<Enemy> enemy_t)
{
    std::shared_ptr<Enemy> enemy = enemy_t;
    xposition = enemy->getXPos();
    yposition = enemy->getYPos();

    if(dynamic_cast<PEnemy*>(enemy.get())){
        type = 1;
    }
    else{
        if(dynamic_cast<XEnemy*>(enemy.get())){
            type = 2;
        }
        else{
            type = 0;
        }
    }
}

void TextEnemy::showDeadEnemy(){

   emit enemyIsKilled(xposition, yposition, type);
   deathcounter++;

}
