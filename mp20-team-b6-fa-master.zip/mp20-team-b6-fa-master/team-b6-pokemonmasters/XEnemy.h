#ifndef XENEMY_H
#define XENEMY_H

#include <QObject>
#include "world.h"
#include <map>

using namespace std;

class XEnemy: public Enemy
{
    Q_OBJECT
public:
    XEnemy(int xPosition, int yPosition, float strength);
    ~XEnemy() override = default;

    void attacked(int x, int y);

signals:
    void positionUpdated(int x, int y);
    void positionUpdatedTwo(int x, int y, int timesAttacked);

private:
    int timesAttacked = 0;
};

#endif // XENEMY_H
