#include "worldcontroller.h"
#include "WorldModel.h"

WorldController::WorldController()
{

    auto world_model = new WorldModel("worldmap4", 5, 5);

}
