#ifndef TEXTENEMY_H
#define TEXTENEMY_H

#include <QObject>
#include "world.h"
#include "ui_mainwindow.h"
#include <QTableWidget>

class TextEnemy: public QObject
{
    Q_OBJECT

public:
    TextEnemy(std::shared_ptr<Enemy> enemy);

private:
    int xposition;
    int yposition;
    int type;
    int deathcounter = 0;

public slots:
    void showDeadEnemy();

signals:
    void enemyIsKilled(int xpos, int ypos, int type);

};

#endif // TEXTENEMY_H
